void setCounter(char * s, int d);
int getCounter(char * s);
void incrementCounter(char * s);
