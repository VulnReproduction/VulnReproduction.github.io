void			PutLatexFile(char *s, double scale, char *options);
void            CmdGraphics(int code);
void 			CmdPicture(int code);
void 			CmdMusic(int code);
