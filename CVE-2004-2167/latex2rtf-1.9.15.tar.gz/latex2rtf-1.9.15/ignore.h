/* $Id: ignore.h,v 1.15 2001/09/26 03:31:50 prahl Exp $ */

bool            TryVariableIgnore(char *command);
void Ignore_Environment(char *endstring);
