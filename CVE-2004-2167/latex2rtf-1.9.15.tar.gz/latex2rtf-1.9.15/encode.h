void WriteEightBitChar(char cThis);
