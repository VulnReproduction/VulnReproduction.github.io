bool TryDirectConvert(char *command);
void WriteFontName(const char **buffpoint);
