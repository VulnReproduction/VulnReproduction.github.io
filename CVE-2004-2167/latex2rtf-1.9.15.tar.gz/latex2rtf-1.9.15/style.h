void InsertBasicStyle(const char *rtf, bool include_header_info);
void InsertStyle(char *command);
